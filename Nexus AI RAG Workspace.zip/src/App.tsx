import { useEffect, useRef, useState } from "react";
import {
  ArrowUp, Check, ChevronDown, CircleUserRound, Clipboard, Command, Database,
  FileSpreadsheet, FileText, FolderOpen, Menu, MessageSquare, Moon, MoreHorizontal,
  PanelRightClose, PanelRightOpen, Paperclip, Plus, RefreshCw, Search, Sun,
  ThumbsDown, ThumbsUp, UploadCloud, X,
} from "lucide-react";

type View = "chat" | "documents";
type Theme = "light" | "dark";

const sources = [
  { id: 1, type: "PDF", title: "Contrat fournisseur Atlas — 2024.pdf", page: "Page 12", score: 96, excerpt: "Chaque partie peut résilier le contrat avec un préavis écrit de quatre-vingt-dix jours, sans motif particulier." },
  { id: 2, type: "PDF", title: "Contrat fournisseur Atlas — 2024.pdf", page: "Page 13", score: 92, excerpt: "En cas de manquement substantiel, la partie lésée adresse une mise en demeure et accorde un délai de trente jours." },
  { id: 3, type: "DOCX", title: "Avenant n°2 — Atlas.docx", page: "Section 4.2", score: 88, excerpt: "La résiliation prend effet immédiatement en cas de violation des obligations de confidentialité ou de sécurité." },
  { id: 4, type: "PDF", title: "Procédure achats — fournisseurs.pdf", page: "Page 28", score: 76, excerpt: "Toute résiliation fournisseur doit être validée par la direction juridique et notifiée par lettre recommandée." },
];

const documents = [
  ["Contrat fournisseur Atlas — 2024.pdf", "PDF", "2,4 Mo", "Indexé", "18 juin 2025"],
  ["Avenant n°2 — Atlas.docx", "DOCX", "842 Ko", "Indexé", "12 juin 2025"],
  ["Procédure achats — fournisseurs.pdf", "PDF", "1,8 Mo", "Indexé", "8 juin 2025"],
  ["Grille tarifaire Atlas.xlsx", "XLSX", "320 Ko", "Indexé", "2 juin 2025"],
  ["Politique de sécurité fournisseurs.pdf", "PDF", "3,1 Mo", "Indexé", "28 mai 2025"],
  ["Accord de confidentialité Atlas.pdf", "PDF", "980 Ko", "Indexé", "24 mai 2025"],
  ["Compte-rendu comité achats.docx", "DOCX", "680 Ko", "En attente", "20 mai 2025"],
  ["Annuaire fournisseurs.csv", "CSV", "164 Ko", "Indexé", "18 mai 2025"],
];

function IconButton({ label, children, className = "", onClick }: { label: string; children: React.ReactNode; className?: string; onClick?: () => void }) {
  return <button className={`icon-button ${className}`} aria-label={label} title={label} onClick={onClick}>{children}</button>;
}

function Citation({ id }: { id: number }) {
  const source = sources[id - 1];
  return <span className="citation-wrap"><button className="citation" aria-label={`Afficher la source ${id}`}>[{id}]</button><span className="citation-popover" role="tooltip"><strong>{source.title}</strong><small>{source.page} · Pertinence {source.score}%</small><span>« {source.excerpt} »</span></span></span>;
}

function Sidebar({ open, close, view, setView }: { open: boolean; close: () => void; view: View; setView: (view: View) => void }) {
  return <aside className={`sidebar ${open ? "open" : ""}`} aria-label="Navigation principale">
    <div className="brand"><span className="brand-mark">N</span><strong>Nexus</strong><IconButton label="Fermer le menu" className="mobile-only" onClick={close}><X size={18}/></IconButton></div>
    <button className="new-conversation" onClick={() => { setView("chat"); close(); }}><Plus size={17}/> Nouvelle conversation</button>
    <nav>
      <button className={view === "chat" ? "nav-active" : ""} onClick={() => { setView("chat"); close(); }}><MessageSquare size={17}/> Conversations</button>
      <button className={view === "documents" ? "nav-active" : ""} onClick={() => { setView("documents"); close(); }}><FolderOpen size={17}/> Documents</button>
    </nav>
    <section className="sidebar-section">
      <p className="section-label">Aujourd’hui</p>
      <button className="history active">Résiliation contrat Atlas</button>
      <button className="history">Délais de paiement fournisseurs</button>
      <p className="section-label">Hier</p>
      <button className="history">Synthèse de l’accord cadre</button>
      <p className="section-label">Cette semaine</p>
      <button className="history">Obligations de confidentialité</button>
    </section>
    <section className="sidebar-section knowledge">
      <p className="section-label">Bases de connaissances</p>
      <button><i className="status-dot green"/> Juridique & Achats <span>48</span></button>
      <button><i className="status-dot blue"/> Politiques internes <span>32</span></button>
      <button><i className="status-dot amber"/> Projets <span>12</span></button>
    </section>
    <div className="profile"><span className="avatar">AM</span><span><strong>Alex Martin</strong><small>Équipe juridique</small></span><MoreHorizontal size={17}/></div>
  </aside>;
}

function Composer({ onSend }: { onSend: (value: string) => void }) {
  const [value, setValue] = useState("");
  const textarea = useRef<HTMLTextAreaElement>(null);
  const send = () => { if (value.trim()) { onSend(value.trim()); setValue(""); if (textarea.current) textarea.current.style.height = "auto"; } };
  return <div className="composer-shell">
    <div className="composer">
      <textarea ref={textarea} rows={1} value={value} aria-label="Votre question" placeholder="Interrogez vos documents…" onChange={(e) => { setValue(e.target.value); e.target.style.height = "auto"; e.target.style.height = `${Math.min(e.target.scrollHeight, 132)}px`; }} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }}}/>
      <div className="composer-actions">
        <IconButton label="Joindre un document"><Paperclip size={18}/></IconButton>
        <button className="select-button"><Database size={15}/> Juridique & Achats <ChevronDown size={14}/></button>
        <button className="select-button model">Nexus 2.1 <ChevronDown size={14}/></button>
        <button className="send-button" disabled={!value.trim()} aria-label="Envoyer" onClick={send}><ArrowUp size={18}/></button>
      </div>
    </div>
    <small>Entrée pour envoyer · Maj + Entrée pour une nouvelle ligne</small>
  </div>;
}

function SourcePanel({ open, close }: { open: boolean; close: () => void }) {
  return <aside className={`sources-panel ${open ? "open" : ""}`} aria-label="Sources récupérées">
    <div className="panel-header"><div><h2>Sources</h2><p>4 passages récupérés</p></div><IconButton label="Fermer les sources" onClick={close}><X size={18}/></IconButton></div>
    <div className="source-list">{sources.map((source) => <article className="source-card" key={source.id}>
      <div className="source-top"><span className="file-type">{source.type === "DOCX" ? <FileText size={16}/> : <FileText size={16}/>}</span><span><strong>{source.title}</strong><small>{source.page}</small></span><span className="source-number">{source.id}</span></div>
      <p>« {source.excerpt.split(/(résilier|préavis|manquement|confidentialité|résiliation)/gi).map((part, i) => /résilier|préavis|manquement|confidentialité|résiliation/i.test(part) ? <mark key={i}>{part}</mark> : part)} »</p>
      <div className="relevance"><span style={{ width: `${source.score}%` }}/></div>
      <div className="source-footer"><small>{source.score}% de pertinence</small><button>Ouvrir le document</button></div>
    </article>)}</div>
  </aside>;
}

function Chat({ sourceOpen, setSourceOpen }: { sourceOpen: boolean; setSourceOpen: (value: boolean) => void }) {
  const [loading, setLoading] = useState(false);
  const [showAnswer, setShowAnswer] = useState(true);
  const ask = () => { setLoading(true); setShowAnswer(false); window.setTimeout(() => { setLoading(false); setShowAnswer(true); setSourceOpen(true); }, 1400); };
  return <div className="chat-layout">
    <section className="chat-main">
      <div className="conversation">
        <div className="chat-title"><span>Juridique & Achats</span><h1>Résiliation du contrat Atlas</h1></div>
        <div className="user-message">Quelles sont les conditions de résiliation du contrat fournisseur Atlas ?</div>
        {loading && <div className="research-state"><div className="skeleton-lines"><i/><i/><i/></div><strong>Recherche dans 12 documents…</strong><div className="steps"><span className="done"><Check size={13}/> Recherche</span><span className="current">Lecture</span><span>Rédaction</span></div></div>}
        {showAnswer && <article className="answer">
          <div className="answer-heading"><span className="assistant-mark">N</span><span><strong>Nexus</strong><small>Réponse fondée sur 4 sources</small></span></div>
          <h2>Le contrat prévoit trois modalités de résiliation.</h2>
          <p><strong>1. Résiliation sans motif.</strong> Chaque partie peut mettre fin au contrat à tout moment, sous réserve d’un <strong>préavis écrit de 90 jours</strong>. La notification doit être adressée par lettre recommandée avec accusé de réception. <Citation id={1}/></p>
          <p><strong>2. Résiliation pour manquement.</strong> En cas de manquement substantiel à une obligation contractuelle, la partie concernée dispose de <strong>30 jours pour y remédier</strong> après réception d’une mise en demeure. À défaut, la résiliation peut être prononcée de plein droit. <Citation id={2}/></p>
          <p><strong>3. Résiliation immédiate.</strong> Aucun délai de remédiation ne s’applique en cas de violation des obligations de confidentialité, d’atteinte à la sécurité des données ou de cessation d’activité. <Citation id={3}/></p>
          <div className="summary"><strong>En pratique</strong><ul><li>Faire valider le motif et la notification par la direction juridique.</li><li>Respecter le préavis de 90 jours, sauf faute grave expressément prévue.</li><li>Conserver la preuve de réception de la notification. <Citation id={4}/></li></ul></div>
          <div className="answer-actions"><IconButton label="Copier"><Clipboard size={16}/></IconButton><IconButton label="Régénérer" onClick={ask}><RefreshCw size={16}/></IconButton><span/><IconButton label="Réponse utile"><ThumbsUp size={16}/></IconButton><IconButton label="Réponse non utile"><ThumbsDown size={16}/></IconButton></div>
        </article>}
      </div>
      <Composer onSend={ask}/>
    </section>
    <SourcePanel open={sourceOpen} close={() => setSourceOpen(false)}/>
  </div>;
}

function Documents() {
  const [uploading, setUploading] = useState(false);
  return <section className="documents-view">
    <header className="documents-heading"><div><p className="eyebrow">BASE DE CONNAISSANCES</p><h1>Documents</h1><p>8 documents · Juridique & Achats</p></div><button className="primary-button" onClick={() => setUploading(true)}><Plus size={17}/> Ajouter des documents</button></header>
    <button className={`dropzone ${uploading ? "uploading" : ""}`} onClick={() => setUploading(true)}><UploadCloud size={24}/><span><strong>{uploading ? "Contrat-cadre-2025.pdf" : "Déposez vos fichiers ici"}</strong><small>{uploading ? "Indexation en cours…" : "PDF, DOCX, XLSX ou CSV · 50 Mo maximum"}</small></span>{uploading && <div className="ingestion"><i className="done">Téléversement</i><i className="done">Découpage</i><i className="active">Embeddings</i><i>Indexé</i></div>}</button>
    <div className="document-toolbar"><div className="segmented"><button className="active">Tous <span>8</span></button><button>Indexés <span>7</span></button><button>En attente <span>1</span></button></div><label className="search-field"><Search size={16}/><input aria-label="Rechercher un document" placeholder="Rechercher"/></label></div>
    <div className="table-wrap"><table><thead><tr><th>Nom</th><th>Type</th><th>Taille</th><th>Statut</th><th>Ajouté le</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>{documents.map((doc) => <tr key={doc[0]}><td><span className="doc-icon">{doc[1] === "XLSX" || doc[1] === "CSV" ? <FileSpreadsheet size={18}/> : <FileText size={18}/>}</span><strong>{doc[0]}</strong></td><td>{doc[1]}</td><td>{doc[2]}</td><td><span className={`status ${doc[3] === "Indexé" ? "indexed" : "pending"}`}><i/>{doc[3]}</span></td><td>{doc[4]}</td><td><IconButton label={`Actions pour ${doc[0]}`}><MoreHorizontal size={17}/></IconButton></td></tr>)}</tbody></table></div>
  </section>;
}

function CommandPalette({ close, setView }: { close: () => void; setView: (view: View) => void }) {
  return <div className="modal-backdrop" onMouseDown={close}><div className="command-palette" role="dialog" aria-modal="true" aria-label="Palette de commandes" onMouseDown={(e) => e.stopPropagation()}>
    <div className="command-search"><Search size={19}/><input autoFocus placeholder="Rechercher une conversation, un document ou une action…"/><kbd>ESC</kbd></div>
    <p className="section-label">Actions rapides</p>
    <button onClick={() => { setView("chat"); close(); }}><Plus size={17}/><span><strong>Nouvelle conversation</strong><small>Interroger la base documentaire</small></span><kbd>⌘ N</kbd></button>
    <button onClick={() => { setView("documents"); close(); }}><FolderOpen size={17}/><span><strong>Ouvrir les documents</strong><small>Gérer les sources indexées</small></span></button>
    <p className="section-label">Résultats récents</p>
    <button><FileText size={17}/><span><strong>Contrat fournisseur Atlas — 2024.pdf</strong><small>Document · Juridique & Achats</small></span></button>
  </div></div>;
}

export default function App() {
  const [view, setView] = useState<View>("chat");
  const [theme, setTheme] = useState<Theme>("light");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sourceOpen, setSourceOpen] = useState(true);
  const [commands, setCommands] = useState(false);
  useEffect(() => {
    const dark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    setTheme(dark ? "dark" : "light");
    const key = (e: KeyboardEvent) => { if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setCommands(true); } if (e.key === "Escape") { setCommands(false); setSidebarOpen(false); } };
    window.addEventListener("keydown", key); return () => window.removeEventListener("keydown", key);
  }, []);
  return <div className="app" data-theme={theme}>
    <Sidebar open={sidebarOpen} close={() => setSidebarOpen(false)} view={view} setView={setView}/>
    {sidebarOpen && <button className="drawer-backdrop" aria-label="Fermer le menu" onClick={() => setSidebarOpen(false)}/>}
    <main>
      <header className="topbar"><div className="topbar-left"><IconButton label="Ouvrir le menu" className="mobile-menu" onClick={() => setSidebarOpen(true)}><Menu size={19}/></IconButton><span className="context-dot"/><strong>{view === "chat" ? "Contrat Atlas" : "Juridique & Achats"}</strong><span className="saved"><Check size={13}/> Synchronisé</span></div><div className="topbar-actions"><button className="command-trigger" onClick={() => setCommands(true)}><Search size={16}/><span>Rechercher</span><kbd><Command size={12}/>K</kbd></button><IconButton label={theme === "dark" ? "Activer le thème clair" : "Activer le thème sombre"} onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? <Sun size={18}/> : <Moon size={18}/>}</IconButton>{view === "chat" && <IconButton label={sourceOpen ? "Masquer les sources" : "Afficher les sources"} onClick={() => setSourceOpen(!sourceOpen)}>{sourceOpen ? <PanelRightClose size={19}/> : <PanelRightOpen size={19}/>}</IconButton>}<CircleUserRound size={25}/></div></header>
      {view === "chat" ? <Chat sourceOpen={sourceOpen} setSourceOpen={setSourceOpen}/> : <Documents/>}
    </main>
    {commands && <CommandPalette close={() => setCommands(false)} setView={setView}/>}
  </div>;
}
